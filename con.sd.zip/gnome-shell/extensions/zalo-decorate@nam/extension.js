const { Meta, Shell } = import.gi;
const Main = imports.ui.main;
let windowTracker;
function init() {
  windowTracker= Shell.WindowTracker.get_default();
  global.display.connect('window-created', (display, window) => {
  if (window.get_wm_class()=== 'Zalo'){
    window.decorated = true;
    }
  });
}

             
             
                        
                        
